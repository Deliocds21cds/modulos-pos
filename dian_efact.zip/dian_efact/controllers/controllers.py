# -*- coding: utf-8 -*-
from odoo import http
from odoo.exceptions import Warning
import os
import base64
import random
import json
import sys
import xlrd
from datetime import datetime
from odoo.http import request

from dianservice.dianservice import Service

class dianefact(http.Controller):
    @http.route('/dianefact/get_nit/', methods=['POST'], type='json', auth="public", website=True)
    def get_nit(self, **kw):
        nit = kw.get('nit')
        xmlPath = os.path.dirname(os.path.abspath(__file__))+'/xml'
        xmlPath = xmlPath.replace("controllers", "models")
        response = {}
        if(nit!=""):
            DianService = Service()
            DianService.setXMLPath(xmlPath)    
        try:
            response = DianService.consultNIT(nit)            
            if not response:
                return { 
                            'nit':nit,
                            'status' :  "El NIT no fue encontrado en registros de la DIAN"
                       }
            else:
                if('error' not in response):
                    return {
                                'status' :  "OK",
                                'nit':nit,
                                'denominacion' : response['denominacion'],
                                'dian_matricula' : response["matricula"]
                            }
                else:
                    return { 
                            'nit':nit,
                            'status' :  "El NIT no fue encontrado en registros de la DIAN"
                       }
        except Exception as e:
            exc_traceback = sys.exc_info()
            #with open('/home/rockscripts/Documents/data.json', 'w') as outfile:
            #   json.dump(getattr(e, 'message', repr(e))+" ON LINE "+format(sys.exc_info()[-1].tb_lineno), outfile)
            return {'status' :  "FAIL"}
                
        
    
    @http.route('/dianefact/get_invoice_qr/', methods=['POST'], type='json', auth="public", website=True)
    def get_invoice_qr(self, **kw):
        orderReference = kw.get('orderReference')

        query = "select invoice_id from pos_order where pos_reference = '"+str(orderReference)+"'"
        request.cr.execute(query)    
        pos_sale = request.cr.fetchone()
        invoice_id = pos_sale[0]

        query = "select qr_image from account_invoice where id = "+str(invoice_id)
        request.cr.execute(query)    
        account_invoice = request.cr.fetchone()
        qr_image = account_invoice[0]
        return qr_image

    @http.route('/dianefact/get_invoice_ticket_journal/', methods=['POST'], type='json', auth="public", website=True)
    def get_invoice_ticket_journal(self, **kw):
        response = {}
        uid = http.request.env.context.get('uid')

        query = "select id, name from account_journal where code in ('INV','FAC','BOL')"
        request.cr.execute(query)    
        journals = request.cr.dictfetchall()
        response["journals"] = journals

        
        query = "select pos_config.id, pos_config.invoice_journal_id from pos_config inner join pos_session on pos_session.user_id = "+str(uid)+" and state = 'opened'"
        request.cr.execute(query)    
        pos_config = request.cr.dictfetchone()
        response["pos_config"] = pos_config
                
        return response

    @http.route('/dianefact/update_current_pos_conf/', methods=['POST'], type='json', auth="public", website=True)
    def update_current_pos_conf(self, **kw):

        posID = kw.get('posID')
        journalID = kw.get('journalID')
        response = {}

        query = "update pos_config set invoice_journal_id = "+str(journalID)+" where id = "+posID
        request.cr.execute(query) 
                
        return True

    @http.route('/dianefact/populate_representants_list/', methods=['POST'], type='json', auth="public", website=True)
    def populate_representants_list(self, **kw):        
        query = "select * from res_representants"
        request.cr.execute(query) 
        representants = request.cr.dictfetchall() 
        return representants

    @http.route('/dianefact/save_representants/', methods=['POST'], type='json', auth="public", website=True)
    def save_representants(self, **kw):
        
        id_representant = kw.get('id_representant')
        id_company = kw.get('id_company')
        doc_type = kw.get('doc_type')
        doc_number = kw.get('doc_number')
        name = kw.get('name')
        position = kw.get('position')
        address = kw.get('address')

        currentDateTime = datetime.now()
        date_added = currentDateTime#currentDateTime.strftime("%H:%M:%S")

        if(int(id_representant)==0):
            params = {}
            params ["search_type"] = "check_exist"
            params ["id_company"] = id_company
            params ["doc_number"] = doc_number
            params ["doc_type"] = doc_type
            representant = self.get_representant(params)
            if(representant):
                return False
            else:
                query = "insert into res_representants (id_company, doc_type, doc_number, name, position, address, date_added) values ('"+str(doc_type)+"', '"+str(doc_type)+"', '"+str(doc_number)+"', '"+str(name)+"', '"+str(position)+"', '"+str(address)+"', '"+str(date_added)+"')"
        else:
            query = "update res_representants set doc_type='"+str(doc_type)+"', doc_number='"+str(doc_number)+"', name='"+str(name)+"', position='"+str(position)+"', address='"+str(address)+"' where id='"+str(id_representant)+"'"

        request.cr.execute(query)
        return True

    @http.route('/dianefact/get_representant/', methods=['POST'], type='json', auth="public", website=True)
    def get_representant(self,data):
        if (data["search_type"]=="check_exist"):
            query = "select * from res_representants where id_company='"+str(data["id_company"])+"' and doc_number = '"+str(data["doc_number"])+"' and doc_type = '"+str(data["doc_type"])+"'"
        else:
            query = "select * from res_representants where id = "+int(data["id_representant"])
        request.cr.execute(query)
        representant = request.cr.dictfetchone()
        return representant

    @http.route('/dianefact/remove_representant/', methods=['POST'], type='json', auth="public", website=True)
    def remove_representant(self, **kw):  
        id_representant = kw.get('id_representant')    
        query = "delete from res_representants where id="+str(id_representant)
        request.cr.execute(query)
        return True

    @http.route('/dianefact/edocs_submit_invoice/', methods=['POST'], type='json', auth="public", website=True)
    def edocs_submit_invoice(self, **kw):
        invoice_id = kw.get('invoice_id') 
        
        query = "select number, company_id, unsigned_document, signed_document, response_document from account_invoice where id = "+str(invoice_id)
        request.cr.execute(query)
        invoice_fields = request.cr.dictfetchone()

        query = "select res_partner.vat, res_company.dian_emisor_nit, res_company.dian_emisor_username, res_company.dian_emisor_password, res_company.dian_api_mode, res_company.dian_certs from res_company left join res_partner on res_partner.company_id = res_company.id where res_company.id = "+str(invoice_fields['company_id'])+" and res_partner.is_company = TRUE"
        request.cr.execute(query)
        company_fields = request.cr.dictfetchone()

        

        secuencia = str(invoice_fields["number"]).split("-")             
        secuencia_serie = secuencia[0]
        secuencia_consecutivo = secuencia[1]

        nombre_archivo_xml = str(secuencia_serie)+str(company_fields["vat"])+str(secuencia_consecutivo)
        nombre_archivo_zip = str("ws_f")+str(company_fields["vat"])+str(secuencia_consecutivo)
        
        dian_data = {
                        "secuencia_consecutivo":secuencia_consecutivo,
                        "dian": {
                                    "nit":str(company_fields["vat"]),
                                    "usuario":str(company_fields["dian_emisor_username"]),
                                    "clave":str(company_fields["dian_emisor_password"]),
                                    "nonce":base64.b64encode(str(random.random()).encode()).decode(),
                                    "created":"2019-04-15"+str("T")+"22:23:35"
                                },
                        "xml":  {
                                    #"signed":base64.b64decode((invoice_fields["signed_document"]))
                                },
                        "licencia": "081OHTGAVHJZ4GOZJGJV"
                    }
        
        xmlPath = str(os.path.dirname(os.path.abspath(__file__))).replace("controllers","models")+'/xml'
        DianService = Service()
        DianService.setXMLPath(xmlPath)
        DianService.fileXmlName = nombre_archivo_xml
        DianService.fileZipName = nombre_archivo_zip
        DianService.initDianAPI("SANDBOX", "sendBill")
        DianResponse = DianService.processInvoiceFromSignedXML(dian_data)

        if(DianResponse["status"] == "OK"):
            # save xml documents steps for reference in edocs
            response_document_filename = str("R_")+nombre_archivo_xml+str(".XML")

            api_message = "ESTADO: "+str(DianResponse["status"])+"\n"+"Fecha Emisión: "+str(DianResponse["body"]["date_submited"])+"\n"+"DESCRIPCIÓN: "+str(DianResponse["body"]["comments"])
            query = "update account_invoice set dian_request_status = 'OK', api_message = '"+str(api_message)+"', response_document = "+DianResponse["xml_response"]+", response_document_filename = '"+str(response_document_filename)+"', dian_request_type = 'Manual e-Docs' where id = "+str(invoice_id)
            request.cr.execute(query)
        else:
            api_message = "ESTADO: "+str(DianResponse["status"])+"\n"+"DESCRIPCIÓN: "+str(DianResponse["body"])+"\n"+"CÓDIGO ERROR: "+str(DianResponse["code"])
            query = "update account_invoice set dian_request_status = 'FAIL', api_message = '"+str(api_message)+"', dian_request_type = 'Manual e-Docs' where id = "+str(invoice_id)
            request.cr.execute(query)

        response = {
                        "dian_request_status":DianResponse["status"],
                        "api_message":api_message
                   }

        return response
    
    @http.route('/dianefact/get_partner/', methods=['POST'], type='json', auth="public", website=True)
    def get_partner(self, **kw):
        partner_id = kw.get('partner_id') 
        
        query = "select * from res_partner where id = "+str(partner_id)
        request.cr.execute(query)
        partner = request.cr.dictfetchone()
        return partner

    @http.route('/dianefact/get_segments/', methods=['POST'], type='json', auth="public", website=True)
    def get_segments(self, **kw):
        segments_selection = [] 
        if(self.check_model_table('dian_productcodes')):
            if(self.check_data_table('dian_productcodes')):       
                query = "select segment_code, segment_name from dian_productcodes group by segment_code, segment_name order by segment_code asc"                
                request.cr.execute(query)
                segments = request.cr.dictfetchall()
                for segment in segments: 
                    segments_selection.append((segment['segment_code'], segment['segment_name']))
            else:
                self.install_product_codes_data()
        else:
            self.install_product_codes_data()
        return segments_selection

    @http.route('/dianefact/get_families/', methods=['POST'], type='json', auth="public", website=True)
    def get_families(self, **kw):
        families_selection = []
        segment_code = kw.get('segment_code')         
        query = "select family_code, family_name from dian_productcodes where segment_code = '"+str(segment_code)+"' group by family_code, family_name order by family_code asc"                
        request.cr.execute(query)
        families = request.cr.dictfetchall()
        for family in families: 
            families_selection.append((family['family_code'], family['family_name']))
        return families_selection
    
    @http.route('/dianefact/get_clases/', methods=['POST'], type='json', auth="public", website=True)
    def get_clases(self, **kw):
        classes_selection = []
        family_code = kw.get('family_code')         
        query = "select clase_code, clase_name from dian_productcodes where family_code = '"+str(family_code)+"' group by clase_code, clase_name order by clase_code asc"                
        request.cr.execute(query)
        classes = request.cr.dictfetchall()
        for family in classes: 
            classes_selection.append((family['clase_code'], family['clase_name']))
        return classes_selection
    
    @http.route('/dianefact/get_products/', methods=['POST'], type='json', auth="public", website=True)
    def get_products(self, **kw):
        products_selection = []
        class_code = kw.get('class_code')         
        query = "select product_code, product_name from dian_productcodes where clase_code = '"+str(class_code)+"' group by product_code, product_name order by product_code asc"                
        request.cr.execute(query)
        products = request.cr.dictfetchall()
        for product in products: 
            products_selection.append((product['product_code'], product['product_name']))
        return products_selection

    def install_product_codes_data(self):
        product_codes = self.get_tribute_entity_product_code()
        for product_code in product_codes:            
            query = "insert into sunat_productcodes (segment_code, segment_name, family_code, family_name, clase_code, clase_name, product_code, product_name) values ('"+str(product_code[0])+"','"+str(product_code[1]).replace("'","`")+"','"+str(product_code[2])+"','"+str(product_code[3]).replace("'","\'")+"','"+str(product_code[4])+"','"+str(product_code[5]).replace("'","`")+"','"+str(product_code[6])+"','"+str(product_code[7]).replace("'","`")+"')"                        
            request.cr.execute(query)

    def get_tribute_entity_product_code(self):
        xmlPath = os.path.dirname(os.path.abspath(__file__))+'/data/product_codes.xls'
        loc = (xmlPath) 
        
        wb = xlrd.open_workbook(loc) 
        sheet = wb.sheet_by_index(0) 
        
        # For row 0 and column 0 
        sheet.cell_value(5, 0)
        row_cells = [] 
        for j in range(sheet.nrows):
            if(j>3):
                row_cell = [] 
                for i in range(sheet.ncols): 
                    # 0 - segment cod
                    # 1 - segment name
                    # 2 - family cod
                    # 3 - family name
                    # 4 - clase cod
                    # 5 - clase name
                    # 6 - product cod
                    # 7 - product name
                    if(i==0 or i == 2 or i == 4 or i == 6):
                        row_cell.append(int(sheet.cell_value(j, i)))
                    else:
                        row_cell.append(str(sheet.cell_value(j, i)))
                row_cells.append(row_cell)

        return (row_cells)

    def check_model_table(self, tablename):
        request.cr.execute("""
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_name = '{0}'
            """.format(tablename.replace('\'', '\'\'')))
        if request.cr.fetchone()[0] == 1:
            return True
        return False
    
    def check_data_table(self, tablename):
        request.cr.execute("""
            SELECT COUNT(*)
            FROM {0}
            """.format(tablename.replace('\'', '\'\'')))
        if request.cr.fetchone()[0] > 0:
            return True
        return False