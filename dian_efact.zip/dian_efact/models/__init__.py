# -*- coding: utf-8 -*-
from . import account_invoice
from . import account_invoice_refund
from . import res_partner
from . import ir_sequence
from . import res_company
from . import delivery_carrier
from . import stock_picking
from . import account_tax
from . import res_respresentants
from . import dian_edocs
from . import product_template
from . import dian_product_codes