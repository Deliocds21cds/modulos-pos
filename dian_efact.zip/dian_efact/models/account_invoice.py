# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import Warning, UserError
from odoo import http
from pprint import pprint
import time
from datetime import datetime
import hmac
import hashlib
import requests 
import json
import os
import random
from odoo.http import request
from decimal import Decimal
import qrcode
import base64
from io import BytesIO

from dianservice.dianservice import Service


class account_invoice(models.Model):

    _inherit = 'account.invoice'
    
    api_message = fields.Text(name="api_message", string="Estado", default='Documento contable sin emitir.', readonly=True)
    discrepance_code = fields.Text(name="discrepance_code", default='', readonly=True)
    discrepance_text = fields.Text(name="discrepance_text", string="Discrepancia", default="", readonly=True)
    
    _columns = { 'api_message': fields.Text('Estado'),'discrepance': fields.Text('Discrepancia')}
    _defaults = {'api_message':'Documento contable sin emitir.','diario':'factura','discrepance':''}

      
    qr_in_report = fields.Boolean('Ver QR en reporte' , default=True)
    unsigned_document = fields.Binary(string="XML - no firmado", default=None, readonly=True, filename="unsigned.XML" ,filters='*.xml')
    unsigned_document_filename = fields.Char("Unsigned Filename")

    signed_document = fields.Binary(string="XML - Firmado", default=None, readonly=True, filename="unsigned.XML" ,filters='*.xml')
    signed_document_filename = fields.Char("Signed Filename")
    
    response_document = fields.Binary(string="XML - respuesta", default=None, readonly=True, filename="unsigned.XML" ,filters='*.xml')
    response_document_filename = fields.Char("Response Filename")
    qr_image = fields.Text(name="qr_image", default='')

    dian_request_status = fields.Text(name="dian_request_status", default='No Emitido')
    dian_request_type = fields.Text(name="dian_request_type", default='Automatizada')
    
    def exist_main_tribute(self,tributos, tributo):
        if(tributos.__len__()>0):
            found = False
            for tributo_code in tributos:
                if(str(tributo_code) == tributo["codigo"]):
                    found = True
        else:
            found = False
        return found

    def exist_child_tribute(self,tributos, tributo):
        if(tributos.__len__()>0):
            found = False
            
            for tributo_code in tributos:
                if(str(tributo_code) == tributo["codigo"]):
                    for tributo_item_percent_differenced in tributos[str(tributo_code)]:                        
                        if(tributo_item_percent_differenced["porcentaje"] == tributo["porcentaje"]):
                            found = True
        else:
            found = False
        return found

    def add_global_tributes(self, item_tributos, tributos_globales):        
        if(item_tributos.__len__()>0):
            
            for item_tributo in item_tributos:
                tributo_global_nuevo = {
                                            "codigo":item_tributo["codigo"],
                                            "total_venta":item_tributo["total_venta"],
                                            "porcentaje":item_tributo["porcentaje"],
                                            "sumatoria":item_tributo["montoAfectacionTributo"]
                                        }

                if(self.exist_main_tribute(tributos_globales,item_tributo)==False):
                    tributos_globales.update({str(item_tributo["codigo"]):[]})                                               
                    tributos_globales[str(item_tributo["codigo"])].append(tributo_global_nuevo)

                else:
                    position_child_tribute = self.exist_child_tribute(tributos_globales, item_tributo)
                    if(position_child_tribute==False):
                        tributos_globales[str(item_tributo["codigo"])].append(tributo_global_nuevo)
                    else:
                        for tributo_item_percent_differenced in tributos_globales[str(item_tributo["codigo"])]:                        
                            if(tributo_item_percent_differenced["porcentaje"] == item_tributo["porcentaje"]):
                                tributo_global_update = {
                                                            "total_venta":(float(tributo_item_percent_differenced["total_venta"])+float(item_tributo["total_venta"])),                                                            
                                                            "sumatoria":(float(tributo_item_percent_differenced["sumatoria"])+float(item_tributo["montoAfectacionTributo"]))
                                                        }

                                tributo_item_percent_differenced.update(tributo_global_update)                      
        
        return tributos_globales
            

    @api.multi
    def invoice_validate(self):
        
        urlPath = http.request.httprequest.full_path
        if 'payment/process' in urlPath:
            return super(account_invoice, self).invoice_validate() 
        
        invoice_items = []       

        for invoice in self: 
            if invoice.partner_id.vat=="" or invoice.partner_id.vat==False:
               raise Warning(_("Por favor, establecer el documento del receptor"))

        eDocumentType = self.journal_id.code
        index = 0
        dian_items = [] 
        totalVentaPedido = 0
        subTotalPedido = 0
        #impuestos
        tributos_globales = {}
        tributos = {}
        dian_request_type = "Automatizada"
        processInvoiceAction = "fill_only"
        
        if(eDocumentType == "NCR"):   
            for invoice in self:  
                dian_request_type = invoice.company_id.dian_request_type 
                if(dian_request_type=="automatic"):
                    dian_request_type = "Automatizada"  
                    processInvoiceAction = "fill_only"    
                else:
                    dian_request_type = "Documento Validado"
                    processInvoiceAction = "fill_submit"
                    
                items = invoice.invoice_line_ids
                for item in items:
                    item_tributos = []
                    subTotalVenta = float((item.price_unit * item.quantity))
                    totalVenta = subTotalVenta
                    for tax in item.invoice_line_tax_ids:                           
                        impuesto = tax.amount/100                                                
                        monto_afectacion_tributo = float((subTotalVenta * impuesto))
                        totalVenta +=  monto_afectacion_tributo
                        item_tributo = {
                                            "codigo":tax.dian_tributo,
                                            "porcentaje":tax.amount,
                                            "montoAfectacionTributo":monto_afectacion_tributo,
                                            "total_venta":subTotalVenta
                                       }
                        item_tributos.append(item_tributo) 

                    tributos_globales = self.add_global_tributes(item_tributos,tributos_globales)
                   
                    dian_item = {
                                    'id':str(item.id),
                                    'cantidad':str(item.quantity),
                                    'descripcion':item.name,
                                    'precioUnidad':item.price_unit, 
                                    'clasificacionProductoServicioCodigo':self.get_sunat_product_code_classification(item.product_id.id),
                                    "subTotalVenta":subTotalVenta,
                                    'totalVenta':totalVenta, 
                                    "tributos":item_tributos
                                }
                    dian_items.append(dian_item)
                    totalVentaPedido += float(totalVenta)
                    subTotalPedido += float(subTotalVenta)

                currentDateTime = datetime.now()
                currentTime = currentDateTime.strftime("%H:%M:%S")                

                secuencia = str(invoice.number).split("-")             
                secuencia_serie = secuencia[0]
                secuencia_consecutivo = secuencia[1]                 

                dian_data = {
                                "serie": str(secuencia_serie),
                                "numero":str(secuencia_consecutivo),
                                "emisor":{
                                            "tipo_documento":invoice.company_id.dian_tipo_documento,
                                            "nro":invoice.company_id.vat,
                                            "nombre":invoice.company_id.name,
                                            "regimen":invoice.company_id.dian_regimen,
                                            "direccion":invoice.company_id.street,
                                            "ciudad":invoice.company_id.city,
                                            "ciudad_sector":invoice.company_id.street2,
                                            "departamento":invoice.company_id.state_id.name,
                                            "codigoPostal":invoice.company_id.zip,
                                            "codigoPais":invoice.company_id.country_id.code
                                         },
                                "receptor": {
                                                "tipo_documento":invoice.partner_id.dian_tipo_documento,
                                                "nro":invoice.partner_id.vat,
                                                "nombre":invoice.partner_id.name,
                                                "regimen":invoice.partner_id.dian_regimen,
                                                "direccion":invoice.partner_id.street,
                                                "ciudad":invoice.partner_id.city,
                                                "ciudad_sector":invoice.partner_id.street2,
                                                "departamento":invoice.partner_id.state_id.name,
                                                "codigoPostal":invoice.partner_id.zip,
                                                "codigoPais":invoice.partner_id.country_id.code
                                            },
                                "CUFE":str("8386338f439385fc7b66a6e3a86b0ced27bf53b6"),
                                "notaDescripcion":self.name,
                                "notaDiscrepanciaCode":self.discrepance_code,
                                "documentoOrigen":self.origin,
                                "fechaEmision":str(invoice.date_invoice).replace("/","-",3),
                                "fechaVencimiento":str(invoice.date_due).replace("/","-",3),
                                "horaEmision":currentTime,
                                "subTotalVenta":subTotalPedido,
                                "totalVentaGravada":totalVentaPedido,
                                "tipoMoneda":invoice.currency_id.name,
                                "items": dian_items,
                                "tributos":tributos_globales,
                                "dian": {
                                            "nit":invoice.company_id.dian_emisor_nit,
                                            "identificador_software":invoice.company_id.dian_emisor_username,
                                            "pin_software":invoice.company_id.dian_emisor_password,
                                            "nonce":base64.b64encode(str(random.random()).encode()).decode(),
                                            "created":str(currentDateTime.year)+"-"+str(currentDateTime.month)+"-"+str(currentDateTime.day)+"T"+str(currentTime),
                                            "autorizacion":{
                                                                "codigo":invoice.company_id.dian_numero_resolucion,
                                                                "codigo_pais":"CO",
                                                                "fecha_inicio":invoice.company_id.dian_fecha_inicio_resolucion,
                                                                "fecha_fin":invoice.company_id.dian_fecha_fin_resolucion,
                                                                "prefijo":invoice.company_id.dian_prefijo_resolucion_periodo,
                                                                "desde":invoice.company_id.dian_desde_resolucion_periodo,
                                                                "hasta":invoice.company_id.dian_hasta_resolucion_periodo
                                                           }
                                        },
                                "accion": processInvoiceAction,
                                "licencia":"081OHTGAVHJZ4GOZJGJV"
                            }
                
                nombre_archivo_xml = str(secuencia_serie)+str(invoice.company_id.vat)+str(secuencia_consecutivo)
                nombre_archivo_zip = str("ws_c")+str(invoice.company_id.vat)+str(secuencia_consecutivo)

                xmlPath = os.path.dirname(os.path.abspath(__file__))+'/xml'
                
                DianService = Service()
                DianService.setXMLPath(xmlPath)
                DianService.fileXmlName = nombre_archivo_xml
                DianService.fileZipName = nombre_archivo_zip
                DianService.initDianAPI(invoice.company_id.dian_api_mode, "sendBill")
                DianResponse = DianService.processCreditNote(dian_data)

                # save xml documents steps for reference in edocs
                self.response_document = DianResponse["xml_response"]
                self.response_document_filename = str("R_")+nombre_archivo_xml+str(".XML")

                self.signed_document = DianResponse["xml_signed"]
                self.signed_document_filename = str("F_")+nombre_archivo_xml+str(".XML")

                self.unsigned_document = DianResponse["xml_unsigned"]
                self.unsigned_document_filename = str("NF_")+nombre_archivo_xml+str(".XML")

                # generate qr for invoices and tickets in pos
                base_url = request.env['ir.config_parameter'].get_param('web.base.url')
                base_url += '/web#id=%d&view_type=form&model=%s' % (self.id, self._name)
                qr = qrcode.QRCode(
                                    version=1,
                                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                                    box_size=20,
                                    border=4,
                                  )
                qr.add_data(base_url)
                qr.make(fit=True)
                img = qr.make_image()
                temp = BytesIO()
                img.save(temp, format="PNG")
                self.qr_image = base64.b64encode(temp.getvalue())
                self.qr_in_report = True
                self.dian_request_type = dian_request_type

                if(DianResponse["status"] == "OK"):                                                                                  
                    self.api_message = "ESTADO: "+str(DianResponse["status"])+"\n"+"Fecha Emisión: "+str(DianResponse["body"]["date_submited"])+"\n"+"DESCRIPCIÓN: "+str(DianResponse["body"]["comments"])
                    self.dian_request_status = 'OK'
                    return super(account_invoice, self).invoice_validate()
                else:
                    self.dian_request_status = 'FAIL'
                    self.api_message = "ESTADO: "+str(DianResponse["status"])+"\n"+"DESCRIPCIÓN: "+str(DianResponse["body"])+"\n"+"CÓDIGO ERROR: "+str(DianResponse["code"])
                    return super(account_invoice, self).invoice_validate()

        elif(eDocumentType == "NDB"):
            for invoice in self:  
                dian_request_type = invoice.company_id.dian_request_type 
                if(dian_request_type=="automatic"):
                    dian_request_type = "Automatizada"  
                    processInvoiceAction = "fill_only"    
                else:
                    dian_request_type = "Documento Validado"
                    processInvoiceAction = "fill_submit"
                    
                items = invoice.invoice_line_ids
                for item in items:
                    item_tributos = []
                    subTotalVenta = float((item.price_unit * item.quantity))
                    totalVenta = subTotalVenta
                    for tax in item.invoice_line_tax_ids:                           
                        impuesto = tax.amount/100                                                
                        monto_afectacion_tributo = float((subTotalVenta * impuesto))
                        totalVenta +=  monto_afectacion_tributo
                        item_tributo = {
                                            "codigo":tax.dian_tributo,
                                            "porcentaje":tax.amount,
                                            "montoAfectacionTributo":monto_afectacion_tributo,
                                            "total_venta":subTotalVenta
                                       }
                        item_tributos.append(item_tributo) 

                    tributos_globales = self.add_global_tributes(item_tributos,tributos_globales)
                   
                    dian_item = {
                                    'id':str(item.id),
                                    'cantidad':str(item.quantity),
                                    'descripcion':item.name, 
                                    'precioUnidad':item.price_unit,
                                    'clasificacionProductoServicioCodigo':self.get_sunat_product_code_classification( item.product_id.id),
                                    "subTotalVenta":subTotalVenta,
                                    'totalVenta':totalVenta, 
                                    "tributos":item_tributos
                                }
                    dian_items.append(dian_item)
                    totalVentaPedido += float(totalVenta)
                    subTotalPedido += float(subTotalVenta)

                currentDateTime = datetime.now()
                currentTime = currentDateTime.strftime("%H:%M:%S")                

                secuencia = str(invoice.number).split("-")             
                secuencia_serie = secuencia[0]
                secuencia_consecutivo = secuencia[1]                 

                dian_data = {
                                "serie": str(secuencia_serie),
                                "numero":str(secuencia_consecutivo),
                                "emisor":{
                                            "tipo_documento":invoice.company_id.dian_tipo_documento,
                                            "nro":invoice.company_id.vat,
                                            "nombre":invoice.company_id.name,
                                            "regimen":invoice.company_id.dian_regimen,
                                            "direccion":invoice.company_id.street,
                                            "ciudad":invoice.company_id.city,
                                            "ciudad_sector":invoice.company_id.street2,
                                            "departamento":invoice.company_id.state_id.name,
                                            "codigoPostal":invoice.company_id.zip,
                                            "codigoPais":invoice.company_id.country_id.code
                                         },
                                "receptor": {
                                                "tipo_documento":invoice.partner_id.dian_tipo_documento,
                                                "nro":invoice.partner_id.vat,
                                                "nombre":invoice.partner_id.name,
                                                "regimen":invoice.partner_id.dian_regimen,
                                                "direccion":invoice.partner_id.street,
                                                "ciudad":invoice.partner_id.city,
                                                "ciudad_sector":invoice.partner_id.street2,
                                                "departamento":invoice.partner_id.state_id.name,
                                                "codigoPostal":invoice.partner_id.zip,
                                                "codigoPais":invoice.partner_id.country_id.code
                                            },
                                "CUFE":str("8386338f439385fc7b66a6e3a86b0ced27bf53b6"),
                                "notaDescripcion":self.name,
                                "notaDiscrepanciaCode":self.discrepance_code,
                                "documentoOrigen":self.origin,
                                "fechaEmision":str(invoice.date_invoice).replace("/","-",3),
                                "fechaVencimiento":str(invoice.date_due).replace("/","-",3),
                                "horaEmision":currentTime,
                                "subTotalVenta":subTotalPedido,
                                "totalVentaGravada":totalVentaPedido,
                                "tipoMoneda":invoice.currency_id.name,
                                "items": dian_items,
                                "tributos":tributos_globales,
                               "dian": {
                                            "nit":invoice.company_id.dian_emisor_nit,
                                            "identificador_software":invoice.company_id.dian_emisor_username,
                                            "pin_software":invoice.company_id.dian_emisor_password,
                                            "nonce":base64.b64encode(str(random.random()).encode()).decode(),
                                            "created":str(currentDateTime.year)+"-"+str(currentDateTime.month)+"-"+str(currentDateTime.day)+"T"+str(currentTime),
                                            "autorizacion":{
                                                                "codigo":invoice.company_id.dian_numero_resolucion,
                                                                "codigo_pais":"CO",
                                                                "fecha_inicio":invoice.company_id.dian_fecha_inicio_resolucion,
                                                                "fecha_fin":invoice.company_id.dian_fecha_fin_resolucion,
                                                                "prefijo":invoice.company_id.dian_prefijo_resolucion_periodo,
                                                                "desde":invoice.company_id.dian_desde_resolucion_periodo,
                                                                "hasta":invoice.company_id.dian_hasta_resolucion_periodo
                                                           }
                                        },
                                "accion": processInvoiceAction,
                                "licencia":"081OHTGAVHJZ4GOZJGJV"
                            }

                nombre_archivo_xml = str(secuencia_serie)+str(invoice.company_id.vat)+str(secuencia_consecutivo)
                nombre_archivo_zip = str("ws_d")+str(invoice.company_id.vat)+str(secuencia_consecutivo)

                xmlPath = os.path.dirname(os.path.abspath(__file__))+'/xml'
                
                DianService = Service()
                DianService.setXMLPath(xmlPath)
                DianService.fileXmlName = nombre_archivo_xml
                DianService.fileZipName = nombre_archivo_zip
                DianService.initDianAPI(invoice.company_id.dian_api_mode, "sendBill")
                DianResponse = DianService.processDebitNote(dian_data)

                # save xml documents steps for reference in edocs
                self.response_document = DianResponse["xml_response"]
                self.response_document_filename = str("R_")+nombre_archivo_xml+str(".XML")

                self.signed_document = DianResponse["xml_signed"]
                self.signed_document_filename = str("F_")+nombre_archivo_xml+str(".XML")

                self.unsigned_document = DianResponse["xml_unsigned"]
                self.unsigned_document_filename = str("NF_")+nombre_archivo_xml+str(".XML")

                # generate qr for invoices and tickets in pos
                base_url = request.env['ir.config_parameter'].get_param('web.base.url')
                base_url += '/web#id=%d&view_type=form&model=%s' % (self.id, self._name)
                qr = qrcode.QRCode(
                                    version=1,
                                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                                    box_size=20,
                                    border=4,
                                    )
                qr.add_data(base_url)
                qr.make(fit=True)
                img = qr.make_image()
                temp = BytesIO()
                img.save(temp, format="PNG")
                self.qr_image = base64.b64encode(temp.getvalue())
                self.qr_in_report = True
                self.dian_request_type = dian_request_type

                if(DianResponse["status"] == "OK"):                                                                                  
                    self.api_message = "ESTADO: "+str(DianResponse["status"])+"\n"+"Fecha Emisión: "+str(DianResponse["body"]["date_submited"])+"\n"+"DESCRIPCIÓN: "+str(DianResponse["body"]["comments"])
                    self.dian_request_status = 'OK'
                    return super(account_invoice, self).invoice_validate()
                else:
                    self.dian_request_status = 'FAIL'
                    self.api_message = "ESTADO: "+str(DianResponse["status"])+"\n"+"DESCRIPCIÓN: "+str(DianResponse["body"])+"\n"+"CÓDIGO ERROR: "+str(DianResponse["code"])
                    return super(account_invoice, self).invoice_validate()

        elif(eDocumentType == "BOL"): 
            index=0
                
        elif(eDocumentType=="FAC" or eDocumentType=="INV"):                        
            for invoice in self:      
                dian_request_type = invoice.company_id.dian_request_type 
                if(dian_request_type=="automatic"):
                    dian_request_type = "Automatizada"  
                    processInvoiceAction = "fill_only"    
                else:
                    dian_request_type = "Documento Validado"
                    processInvoiceAction = "fill_submit"

                items = invoice.invoice_line_ids
                for item in items:
                    item_tributos = []
                    subTotalVenta = float((item.price_unit * item.quantity))
                    totalVenta = subTotalVenta
                    for tax in item.invoice_line_tax_ids:                           
                        impuesto = tax.amount/100                                                
                        monto_afectacion_tributo = float((subTotalVenta * impuesto))
                        totalVenta +=  monto_afectacion_tributo
                        item_tributo = {
                                            "codigo":tax.dian_tributo,
                                            "porcentaje":tax.amount,
                                            "montoAfectacionTributo":monto_afectacion_tributo,
                                            "total_venta":subTotalVenta
                                       }
                        item_tributos.append(item_tributo) 

                    tributos_globales = self.add_global_tributes(item_tributos,tributos_globales)
                   
                    dian_item = {
                                    'id':str(item.id),
                                    'cantidad':str(item.quantity),
                                    'descripcion':item.name, 
                                    'precioUnidad':item.price_unit,
                                    'clasificacionProductoServicioCodigo':self.get_sunat_product_code_classification( item.product_id.id),
                                    "subTotalVenta":subTotalVenta,
                                    'totalVenta':totalVenta, 
                                    "tributos":item_tributos
                                }
                    dian_items.append(dian_item)
                    totalVentaPedido += float(totalVenta)
                    subTotalPedido += float(subTotalVenta)

                currentDateTime = datetime.now()
                currentTime = currentDateTime.strftime("%H:%M:%S")                

                secuencia = str(invoice.number).split("-")             
                secuencia_serie = secuencia[0]
                secuencia_consecutivo = secuencia[1]                 

                dian_data = {
                                "serie": str(secuencia_serie),
                                "numero":str(secuencia_consecutivo),
                                "emisor":{
                                            "tipo_documento":invoice.company_id.dian_tipo_documento,
                                            "nro":invoice.company_id.vat,
                                            "nombre":invoice.company_id.name,
                                            "regimen":invoice.company_id.dian_regimen,
                                            "direccion":invoice.company_id.street,
                                            "ciudad":invoice.company_id.city,
                                            "ciudad_sector":invoice.company_id.street2,
                                            "departamento":invoice.company_id.state_id.name,
                                            "codigoPostal":invoice.company_id.zip,
                                            "codigoPais":invoice.company_id.country_id.code
                                         },
                                "receptor": {
                                                "tipo_documento":invoice.partner_id.dian_tipo_documento,
                                                "nro":invoice.partner_id.vat,
                                                "nombre":invoice.partner_id.name,
                                                "regimen":invoice.partner_id.dian_regimen,
                                                "direccion":invoice.partner_id.street,
                                                "ciudad":invoice.partner_id.city,
                                                "ciudad_sector":invoice.partner_id.street2,
                                                "departamento":invoice.partner_id.state_id.name,
                                                "codigoPostal":invoice.partner_id.zip,
                                                "codigoPais":invoice.partner_id.country_id.code
                                            },
                                "CUFE":str("8386338f439385fc7b66a6e3a86b0ced27bf53b6"),
                                "fechaEmision":str(invoice.date_invoice).replace("/","-",3),
                                "fechaVencimiento":str(invoice.date_due).replace("/","-",3),
                                "horaEmision":currentTime,
                                "subTotalVenta":subTotalPedido,
                                "totalVentaGravada":totalVentaPedido,
                                "tipoMoneda":invoice.currency_id.name,
                                "items": dian_items,
                                "tributos":tributos_globales,
                                "dian": {
                                            "nit":invoice.company_id.dian_emisor_nit,
                                            "identificador_software":invoice.company_id.dian_emisor_username,
                                            "pin_software":invoice.company_id.dian_emisor_password,
                                            "nonce":base64.b64encode(str(random.random()).encode()).decode(),
                                            "created":str(currentDateTime.year)+"-"+str(currentDateTime.month)+"-"+str(currentDateTime.day)+"T"+str(currentTime),
                                            "autorizacion":{
                                                                "codigo":invoice.company_id.dian_numero_resolucion,
                                                                "codigo_pais":"CO",
                                                                "fecha_inicio":invoice.company_id.dian_fecha_inicio_resolucion,
                                                                "fecha_fin":invoice.company_id.dian_fecha_fin_resolucion,
                                                                "prefijo":invoice.company_id.dian_prefijo_resolucion_periodo,
                                                                "desde":invoice.company_id.dian_desde_resolucion_periodo,
                                                                "hasta":invoice.company_id.dian_hasta_resolucion_periodo
                                                           }
                                        },
                                "accion": processInvoiceAction,
                                "licencia":"081OHTGAVHJZ4GOZJGJV"
                            }
                
                

                nombre_archivo_xml = str(secuencia_serie)+str(invoice.company_id.vat)+str(secuencia_consecutivo)
                nombre_archivo_zip = str("ws_f")+str(invoice.company_id.vat)+str(secuencia_consecutivo)

                xmlPath = os.path.dirname(os.path.abspath(__file__))+'/xml'
                
                DianService = Service()
                DianService.setXMLPath(xmlPath)
                DianService.fileXmlName = nombre_archivo_xml
                DianService.fileZipName = nombre_archivo_zip
                DianService.initDianAPI("SANDBOX", "sendBill")
                DianResponse = DianService.processInvoice(dian_data)

                # save xml documents steps for reference in edocs
                self.response_document = DianResponse["xml_response"]
                self.response_document_filename = str("R_")+nombre_archivo_xml+str(".XML")

                self.signed_document = DianResponse["xml_signed"]
                self.signed_document_filename = str("F_")+nombre_archivo_xml+str(".XML")

                self.unsigned_document = DianResponse["xml_unsigned"]
                self.unsigned_document_filename = str("NF_")+nombre_archivo_xml+str(".XML")
                
                # generate qr for invoices and tickets in pos
                base_url = request.env['ir.config_parameter'].get_param('web.base.url')
                base_url += '/web#id=%d&view_type=form&model=%s' % (self.id, self._name)
                qr = qrcode.QRCode(
                                    version=1,
                                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                                    box_size=20,
                                    border=4,
                                    )
                qr.add_data(base_url)
                qr.make(fit=True)
                img = qr.make_image()
                temp = BytesIO()
                img.save(temp, format="PNG")
                self.qr_image = base64.b64encode(temp.getvalue())
                self.qr_in_report = True

                self.dian_request_type = dian_request_type

                if(DianResponse["status"] == "OK"):                                                                                  
                    self.api_message = "ESTADO: "+str(DianResponse["status"])+"\n"+"Fecha Emisión: "+str(DianResponse["body"]["date_submited"])+"\n"+"DESCRIPCIÓN: "+str(DianResponse["body"]["comments"])
                    self.dian_request_status = 'OK'
                    return super(account_invoice, self).invoice_validate()
                else:
                    self.dian_request_status = 'FAIL'
                    self.api_message = "ESTADO: "+str(DianResponse["status"])+"\n"+"DESCRIPCIÓN: "+str(DianResponse["body"])+"\n"+"CÓDIGO ERROR: "+str(DianResponse["code"])
                    return super(account_invoice, self).invoice_validate()
        else:
            return super(account_invoice, self).invoice_validate()
    
    def get_sunat_product_code_classification(self, item_id):
        query = "select sunat_product_code from product_template where id = "+str(item_id)
        request.cr.execute(query)
        product = request.cr.dictfetchone()
        sunat_product_code_parts = str(product["sunat_product_code"]).split(" -- ")
        return sunat_product_code_parts[0]