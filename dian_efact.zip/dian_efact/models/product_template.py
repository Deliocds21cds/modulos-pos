from odoo import models, fields, api
import xlrd
import os, json
from odoo.http import request

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    hs_code = fields.Char(
                            string="HS Code",
                            help="Standardized code for international shipping and goods declaration. At the moment, only used for the FedEx shipping provider.",
                         )
    service_to_purchase = fields.Boolean("Purchase Automatically", help="If ticked, each time you sell this product through a SO, a RfQ is automatically created to buy the product. Tip: don't forget to set a vendor on the product.")    
    sunat_product_code = fields.Char(string="Código Producto")