# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import Warning
from pprint import pprint
import importlib
import os

class res_company(models.Model):  
        
    _inherit = 'res.company'

    dian_regimen = fields.Selection([('0','Ventas Régimen común'),('1','Persona Jurídica'),('2','Gran Contribuyente'),('3','Auto Retenedor')], string='Régimen', default='0')
    dian_tipo_documento = fields.Selection([('13','Cédula de ciudadanía'),('31','NIT'),('11','Registro civil'),('41','Pasaporte'),('12','Tarjeta de identidad'),('21','Tarjeta de extranjería'),('22','Cédula de extranjería'),('42','Documento de identificación extranjero'),('91','NUIP *')], string='Tipo Documento', default='31')
    _columns = {
                    "dian_regimen":fields.Selection([('0','Ventas Régimen común'),('1','Persona Jurídica'),('2','Gran Contribuyente'),('3','Auto Retenedor')], string='Régimen', default='0'),
                    "dian_tipo_documento":fields.Selection([('13','Cédula de ciudadanía'),('31','NIT'),('11','Registro civil'),('41','Pasaporte'),('12','Tarjeta de identidad'),('21','Tarjeta de extranjería'),('22','Cédula de extranjería'),('42','Documento de identificación extranjero'),('91','NUIP *')], string='Tipo Documento', default='31')
               } 

    dian_emisor_nit = fields.Char(name="dian_emisor_nit", string="NIT Software", default='20603408111')
    dian_emisor_username = fields.Char(name="dian_emisor_username", string="Identificador Software", default='20603408111MODDATOS')
    dian_emisor_password = fields.Char(name="dian_emisor_password", string="PIN Software", default='moddatos')
    dian_api_mode = fields.Selection([('SANDBOX','SANDBOX'),('PRODUCTION','PRODUCTION')], string='Modo Servicio', default='SANDBOX')
    dian_request_type = fields.Selection([('automatic','Automatizada'),('validated','Documento Validado')], string='Tipo de Emisión', default='automatic')
    dian_certs = fields.Selection([('cert_1','Cert 1'),('cert_2','Cert 2')], string='Certificado', default='cert_1')

    # software
    dian_numero_resolucion = fields.Char(name="dian_numero_resolucion", string="Número Resolución")
    dian_fecha_inicio_resolucion = fields.Char(name="dian_fecha_inicio_resolucion", string="Fecha Inicio Resolución")
    dian_fecha_fin_resolucion = fields.Char(name="dian_fecha_fin_resolucion", string="Fecha Fin Resolución")
    dian_prefijo_resolucion_periodo = fields.Char(name="dian_prefijo_resolucion_periodo", string="Prefijo")
    dian_desde_resolucion_periodo = fields.Char(name="dian_desde_resolucion_periodo", string="Desde")
    dian_hasta_resolucion_periodo = fields.Char(name="dian_hasta_resolucion_periodo", string="Hasta")
    
    @api.model
    def get_current_id(self):
        return self.env.context.get('active_ids', [])
