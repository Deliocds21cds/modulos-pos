# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import Warning
from odoo import http
from pprint import pprint
import importlib
import os, json
from odoo.http import request

from dianservice.dianservice import Service
import logging

_logger = logging.getLogger(__name__)

class res_partner(models.Model):
    _inherit = 'res.partner'    
    
    dian_regimen = fields.Selection([('0','Ventas Régimen común'),('1','Persona Jurídica'),('2','Gran Contribuyente'),('3','Auto Retenedor')], string='Régimen', default='0')
    dian_tipo_documento = fields.Selection([('13','Cédula de ciudadanía'),('31','NIT'),('11','Registro civil'),('41','Pasaporte'),('12','Tarjeta de identidad'),('21','Tarjeta de extranjería'),('22','Cédula de extranjería'),('42','Documento de identificación extranjero'),('91','NUIP *')], string='Tipo Documento', default='31')
    dian_matricula = fields.Char(name="dian_matricula", string="Matricula Mercantil", default='')
    _columns = {
                    "dian_regimen":fields.Selection([('0','Ventas Régimen común'),('1','Persona Jurídica'),('2','Gran Contribuyente'),('3','Auto Retenedor')], string='Régimen', default='0'),
                    "dian_tipo_documento":fields.Selection([('13','Cédula de ciudadanía'),('31','NIT'),('11','Registro civil'),('41','Pasaporte'),('12','Tarjeta de identidad'),('21','Tarjeta de extranjería'),('22','Cédula de extranjería'),('42','Documento de identificación extranjero'),('91','NUIP *')], string='Tipo Documento', default='31')
               } 
    
    @api.model
    def create_from_ui(self, partner):
        """ create or modify a partner from the point of sale ui.
            partner contains the partner's fields. """
        # image is a dataurl, get the data after the comma
        if partner.get('image'):
            partner['image'] = partner['image'].split(',')[1]
        partner_id = partner.pop('id', False)
        if partner_id:  # Modifying existing partner
            self.browse(partner_id).write(partner)
        else:
            partner['lang'] = self.env.user.lang
            partner_id = self.create(partner).id

        if('dian_tipo_documento' in partner and int(partner['dian_tipo_documento'])>0):
            query = "update res_partner set  dian_tipo_documento= '"+str(partner['dian_tipo_documento'])+"' where id="+str(partner_id)
            request.cr.execute(query) 
            #self.browse(partner_id).write({"dian_tipo_documento":partner['dian_tipo_documento']})

        return partner_id

    #This function should work as controller do  /dianefact/get_nit but it takes long time requesting on pypi pkg       
    #@api.onchange('vat')
    #def on_change_vat(self): 
    #    xmlPath = os.path.dirname(os.path.abspath(__file__))+'/xml'
    #    for record in self:
    #        if (record.vat) :
    #            nit = record.vat
    #            if(nit!=""):
    #                DianService = Service()
    #                DianService.setXMLPath(xmlPath)
    #                response = {}
    #                try:
    #                    response = DianService.consultNIT(str(nit))
    #                    if 'denominacion' not in response:
    #                        raise Warning("El NIT no fue encontrado en registros de la DIAN")
    #                    else:
    #                        if('error' not in response):
    #                            self.name = response["denominacion"]
    #                            self.dian_matricula = response["dian_matricula"]
    #                except Exception as e:                        
    #                    response = "Servicio no disponible temporalmente."
    #                    return response