from odoo import api, fields, models, _
from odoo.exceptions import Warning
from odoo.osv import osv
import json
import os

from sunatservice.sunatservice import Service

class stock_picking(models.Model):
    _inherit = 'stock.picking'
    api_message = fields.Text(name="api_message", string="Estado", default='Documento contable sin emitir.')

    @api.multi
    def action_done(self):
        name = ''
        for pick in self:
            if pick.id:
                name = pick.name
                stocks_picking = self.env['stock.move.line'].search([('picking_id','=',pick.id)])

                
                items = []
                for stock_pick in stocks_picking:
                    #Getting company
                    company = self.env['res.company'].search([('id','=',int(pick.company_id))])
                    #company.name
                    #company.dian_emisor_nit
                    #company.country_id.code
                    #company.street

                    #Getting partner
                    partner = self.env['res.partner'].search([('id','=',int(pick.partner_id))])
                    #partner.name
                    #partner.vat
                    #partner.country_id.code
                    #partner.street                                        

                    #Getting products
                    product = self.env['product.product'].search([('id','=',int(stock_pick.product_id))])
                    item = {
                               "id":str(stock_pick.product_id.id),
                               "nombre":str(product.name),
                               "cantidad":str(stock_pick.product_qty),
                               "unidadMedidaCantidad":str('ZZ'),
                           }
                    items.append(item)

                    #Getting carrier
                    carrier = self.env['delivery.carrier'].search([('id','=',int(pick.carrier_id))])
                    #carrier.ruc
                    #carrier.name

                    serieParts = str(pick.name).split("-")     
                    #disable for proveedores
                    if(serieParts[0]):                        
                        if("T" not in serieParts[0]): 
                            res = super(stock_picking, self).action_done()
                            for pick in self:
                                if pick.carrier_id:
                                    if pick.carrier_id.integration_level == 'rate_and_ship':
                                        pick.send_to_shipper()
                                    pick._add_delivery_cost_to_so()  
                            return res  

                    serieConsecutivoString = serieParts[0]
                    serieConsecutivo = serieParts[1]     

                    dateParts = str(pick.date).split(" ")
                    
                    data = {
                                'serie': str(serieConsecutivoString),
                                "numero":str(serieConsecutivo),
                                "fechaEmision":str(dateParts[0]).replace("/","-",3),
                                "nota":str(pick.note),
                                "peso":str(pick.weight),
                                "emisor":{
                                            "tipo":6,
                                            "nro":company.dian_emisor_nit,
                                            "nombre":company.name,
                                            "direccion":company.street,
                                            "codigoPais":company.country_id.code
                                         },
                                "receptor":{
                                                "tipo":6,
                                                "nro":partner.vat,
                                                "nombre":partner.name,
                                                "direccion":partner.street,
                                                "codigoPais":partner.country_id.code
                                            },
                                "ubigeo":{
                                            "origen":int(company.ubigeo),
                                            "destino":int(partner.ubigeo),
                                         },
                                "transportista":{
                                                    "nro":carrier.ruc,
                                                    "nombre":carrier.name
                                                },
                                "items":items, 
                                'sol':{
                                        'usuario':company.dian_emisor_username,
                                        'clave':company.dian_emisor_password
                                      },
                                'licencia':"081OHTGAVHJZ4GOZJGJV"                           
                           }
                

                if(data['transportista']['nro']==False):
                    raise Warning('Debes establecer un transportista')

                if(data['receptor']['nro']==False):
                    raise Warning('Debes establecer un receptor')

                xmlPath = os.path.dirname(os.path.abspath(__file__))+'/xml'
                SunatService = Service()
                SunatService.setXMLPath(xmlPath)
                SunatService.fileName = str(company.dian_emisor_nit)+"-09-"+str(serieConsecutivoString)+"-"+str(serieConsecutivo)
                SunatService.initSunatAPI(company.dian_api_mode, "sendBill")
                sunatResponse = SunatService.processDeliveryGuide(data)

                #with open('/home/rockscripts/Documents/data1.json', 'w') as outfile:
                #    json.dump(sunatResponse, outfile)

                #original code segment
                res = super(stock_picking, self).action_done()
                for pick in self:
                    if pick.carrier_id:
                        if pick.carrier_id.integration_level == 'rate_and_ship':
                            pick.send_to_shipper()
                        pick._add_delivery_cost_to_so()                                 
                    

                if(sunatResponse["status"] == "OK"):
                    self.api_message = "ESTADO: "+str(sunatResponse["status"])+"\n"+"REFERENCIA: "+str(sunatResponse["body"]["referencia"])+"\n"+"DESCRIPCIÓN: "+str(sunatResponse["body"]["description"])
                    return res
                else:
                    errorMessage = "ESTADO: "+str(sunatResponse["status"])+"\n"+"DESCRIPCIÓN: "+str(sunatResponse["body"])+"\n"+"CÓDIGO ERROR: "+str(sunatResponse["code"])
                    raise Warning(errorMessage)    