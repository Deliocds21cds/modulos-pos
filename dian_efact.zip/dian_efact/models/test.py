import xlrd
import os

def compute_tribute_entity_product_code():
    xmlPath = os.path.dirname(os.path.abspath(__file__))+'/data/product_codes.xls'
    loc = (xmlPath) 
    
    wb = xlrd.open_workbook(loc) 
    sheet = wb.sheet_by_index(0) 
    
    # For row 0 and column 0 
    sheet.cell_value(5, 0)
    row_cells = [] 
    for j in range(5): #range(sheet.nrows):
        if(j>3):
            row_cell = [] 
            for i in range(sheet.ncols): 
                # 0 - segment cod
                # 1 - segment name
                # 2 - family cod 
                # 3 - family name
                # 4 - clase cod
                # 5 - clase name
                # 6 - product cod
                # 7 - product name
                if(i==0 or i == 2 or i == 4 or i == 6):
                    row_cell.append(int(sheet.cell_value(j, i)))
                else:
                    row_cell.append(str(sheet.cell_value(j, i)))
            row_cells.append(row_cell)

    return (row_cells)

compute_tribute_entity_product_code()