odoo.define('module.DianInvoice', function(require) {
    "use strict";
    var rpc = require('web.rpc');

    $(document).ready(function() {
        var flagLoaded = false;
        var mainIntervalTime = 2500;
        setInterval(function() {
            $(document).on("blur", ".div_vat input", function() {
                var ruc = $(".div_vat input").val();
                var data = { "params": { 'nit': ruc } }
                $.ajax({
                    type: "POST",
                    url: '/dianefact/get_nit',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    contentType: "application/json",
                    async: false,
                    success: function(response) {
                        console.log(response)
                        if (response.result.status == "OK") {
                            $("input[name=name]").val(response.result.denominacion);
                            //$(".client-address-street").val(response.result.address);
                            //$(".client-address-city").val(response.result.city);
                            swal("La empresa es valida", "", "success");
                        } else {
                            swal(response.result.status, "", "warning");
                        }
                    }
                });
            })
        }, mainIntervalTime);
    })
})